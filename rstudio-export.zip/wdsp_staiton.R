library(aimsir17)
library(astsa)
library(dplyr)
library(forecast)
library(ggplot2)
library(MLmetrics)
library(tseries)

# pick up the west of Ireland County
west <- filter(stations, county %in% c("Galway","Mayo","Roscommon"))
# pick the stations
west_stations <- west$station

# pick up daily weather(msl,wdsp and rainfall)
daily_weather <- observations %>%
  group_by(station,year,month,day) %>%
  summarise(Time=first(date),
            AvrWdsp=mean(wdsp,na.rm = T),
            TotalRainfall=sum(rain,na.rm = T),
            AvrMsl=mean(msl,na.rm = T),
            MaxTemp=max(temp))

daily_demand <- eirgrid17 %>%
  group_by(month,day) %>%
  summarise(Time=first(date),
            AvrHrDemand=mean(IEDemand),
            AvrWindGen=mean(IEGeneration))


# pick up west stations
train_data <- filter(daily_weather,station %in% west_stations,month  %in% 1:2)

# creat graphic for real wdsp in west stations
ggplot(train_data,aes(x=AvrMsl,y=AvrWdsp))+geom_point()+facet_wrap(~station)

ts_data <- pull(train_data,AvrWdsp)

training_prop <- .5

ts_weather <- ts(ts_data,start=1,end=length(ts_data),frequency=1)
training_data <- window(ts_weather, start = 1, end = length(ts_weather)*training_prop)
test_data <- window(ts_weather, start = length(ts_weather)*training_prop+1, end=length(ts_weather))




