library(aimsir17)
library(astsa)
library(dplyr)
library(forecast)
library(ggplot2)
library(MLmetrics)
library(tseries)
library(xts)

# average all IE demand in 2017
# forecasting all daily average IE Demand in 2017

demand <- eirgrid17 %>%
  group_by(month,day) %>%
  summarise(Time=first(date),
            AvrDailyDemand=mean(IEDemand,na.rm=T),
            AvrWindGen=mean(IEGeneration))

# average demand by day of the week
ggplot(demand, aes(as.factor(strftime(demand$Time, format = '%A')), AvrDailyDemand)) + geom_boxplot() + xlab('Day') + ylab('Demand') + ggtitle('Demand per day of the week')

ggplot(demand, aes(Time, AvrDailyDemand)) + geom_line() + geom_smooth()

ts_data <- pull(test,AvrDailyDemand)

par(mfrow=c(2,2))
acf(demand$AvrDailyDemand, 100, main = 'Autocorrelation')
acf(demand$AvrDailyDemand, 1500, main = 'Autocorrelation')
pacf(demand$AvrDailyDemand, 100, main = 'Partial autocorrelation')
pacf(demand$AvrDailyDemand, 1500, main = 'Partial autocorrelation')


par(mfrow=c(1,2),no.readonly = TRUE)
demandts <- xts(demand$AvrDailyDemand, demand$Time)
ts_Demand <- ts(demand$AvrDailyDemand,frequency = 1)
plot(demandts, main = 'xtsEnergy demand evolution', xlab = 'Date', ylab = 'Demand')
plot(ts_Demand, main = 'tsEnergy demand evolution', xlab = 'Date', ylab = 'Demand')

par(mfrow=c(1,1))

wts <- ts(ts_Demand, frequency = 7)
dec_wts <- decompose(wts)
plot(dec_wts)

plot(ts_Demand, type = 'l', main = 'Real vs. forecast', col = 'red')
line(test$AvrDailyDemand)
legend('topright', c('Real', 'Forecast'), lty = 1, col = c('black', 'red'))


###################################

au <- auto.arima(ts_Demand,trace=T)

auxts <- ts_Demand
auxmodel <- au
predict(auxmodel, newdata = auxts, n.ahead = 1)
errs <- c()
pred <- c()
perc <- c()
for (i in 1:nrow(demand)) {
  p <- as.numeric(predict(auxmodel, newdata = auxts, n.ahead = 1)$pred)
  pred <- c(pred, p)
  errs <- c(errs, p - demand$AvrDailyDemand[i])
  perc <- c(perc, (p - demand$AvrDailyDemand[i]) / demand$AvrDailyDemand[i])
  auxts <- ts(c(auxts, demand$AvrDailyDemand[i]), frequency = 7)
  auxmodel <- Arima(auxts, model = auxmodel)
 }
par(mfrow = c(1, 1))
plot(errs, type = 'l', main = 'Error in the forecast')
pred

plot(pred, type = 'l', main = 'Real vs. forecast', col = 'red')
lines(demand$AvrDailyDemand)
legend('topright', c('Real', 'Forecast'), lty = 1, col = c('black', 'red'))


###################################


