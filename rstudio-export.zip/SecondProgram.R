# covert miles to kilometers (use 1.6)
  mile <- readline("Please Enter mile: ")
  mile <- as.integer(mile)
  print(paste("mile ", mile, " is kilometers ", mile*1.6))
  
  
  #  Convert Celsius to Fahrenheit (9/5 C + 32)
  Cel <- readline("please input Celsius: ")
  #   please input Celsius: 20
  F <- as.integer(Cel) * (9/5) + 32
   print(paste("Celsius ", as.integer(Cel), " is Fahrenheit ", F))
  #   [1] "Celsius  20  is Fahrenheit  68"
   
   