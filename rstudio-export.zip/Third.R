
library(aimsir17)
library(dplyr)
library(ggplot2)
dt <- ggplot2::mpg
ggplot(data = dt) + geom_point(mapping = aes(x=displ, y=hwy))

observations
ggplot(data = observations) + geom_(mapping = aes(x=msl, y=wdsp, color = stations))

# diffrent shape and circle to display
ggplot(data = mpg, aes(x=displ, y=hwy, colour=class, size = cyl, shape = drv)) + geom_point()

