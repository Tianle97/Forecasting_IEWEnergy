summ <- Sept16_Oct20_avg %>% group_by(station,month,day)%>% ungroup()

testMH <- filter(summ,station=="MACE HEAD")   ## %>% slice(1:20)
tsMH_data <- pull(testMH,MeanIEWindGeneration)
training_prop <- .8
ts1       <- ts(tsMH_data,start=1,end=length(tsMH_data))
trainMH_set <- window(ts1,1,floor(length(ts1)*training_prop))
testMH_set  <- window(ts1,floor(length(ts1)*training_prop)+1,length(ts1))
## naiveMH = snaive(trainMH_set, h=length(testMH_set))
## MAPE(naiveMH$mean, testMH_set) * 100

aoMH = auto.arima(trainMH_set)
predict(aoMH,n.ahead = 10,se.fit=T)
f_MH <- forecast(aoMH,h=10)
plot(f_MH)


testAY <- filter(summ,station=="ATHENRY")   ## %>% slice(1:20)
tsAY_data <- pull(testAY,meanWdsp)
training_prop <- .8
tsAY       <- ts(tsAY_data,start=1,end=length(tsAY_data))
trainAY_set <- window(tsAY,1,floor(length(tsAY)*training_prop))
testAY_set  <- window(tsAY,floor(length(tsAY)*training_prop)+1) ##,length(tsAY))
## naiveAY = naive(trainAY_set, h=length(testAY_set))
## MAPE(naiveAY$mean, testAY_set) * 100

aoAY = auto.arima(trainAY_set)
predict(aoAY,n.ahead = 10,se.fit=T)
f_AY <- forecast(aoAY,h=10)
plot(f_AY)





###########################################
## 3.22 code
############################################


################
real_data <- filter(hr_demand,Time>="2017-01-01 00:00:00" , Time<="2017-02-01 23:59:59")
pull_data  <- pull(real_data,AvrHrDemand)
ts_ <- ts(pull_data,start=1,end=length(pull_data), frequency = 1)

training_data <- window(ts_, start = 1, end = length(pull_data)-24)
test_data <- window(hr_data, start = 1, end  = length(pull_data))

########################
hr_data <- pull(hr_test,AvrHrDemand)

hr_ts <- ts(hr_data, start=1,frequency = 24)#,end=32,frequency = 24)
autoplot(hr_ts) +
  ggtitle("Real hourly IEDemand") +
  ylab("AvrHrDemand") 

training_prop <- .8
training_data <- window(hr_ts, start = 1)
test_data <- window(hr_ts, start = floor(length(hr_ts)*training_prop+1), end  = length(hr_ts))

arima_optimal <- auto.arima(hr_ts,d=1,D=1,stepwise = FALSE,approximation = FALSE)



arima_optimal

sarima_forecast = sarima.for(training_data, n.ahead=length(test_data),
                             p=1,d=1,q=0,P=0,D=1,Q=0,S=24)

MAPE(sarima_forecast$pred, test_data) * 100


f <- predict(arima_optimal, n.ahead=24)

f$pred
frc <-  forecast(arima_optimal,h=24)

plot(forecast(arima_optimal,h=24), type="l")
ggplot(filter(hr_demand,Time>="2017-01-01 00:00:00" , Time<="2017-02-01 23:59:59"),aes(x=Time,y=AvrHrDemand))+geom_line()

plot(ts_)

autoplot(frc,include = 60) +
  #autolayer(forecast(arima_optimal,h=24),series="forecast", PI=FALSE) +
  ggtitle("Forecasts for hourly IEDemand") +
  ylab("AvrHrDemand") +
  guides(colour=guide_legend(title="Forecast"))



