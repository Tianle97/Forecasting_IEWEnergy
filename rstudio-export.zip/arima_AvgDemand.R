library(aimsir17)
library(astsa)
library(dplyr)
library(forecast)
library(ggplot2)
library(MLmetrics)
library(tseries)

# use naive method forecasting IEDemand,
demand <- eirgrid17 %>%
  group_by(month,day) %>%
  summarise(Time=first(date),
            AvrDemand=mean(IEDemand),
            AvrWindGen=mean(IEGeneration))

# pick up one month data for training
test <- filter(demand,month %in% 1:10)
# creat graphic for real IEDemand in Jan
ggplot(test,aes(x=Time,y=AvrDemand))+geom_line()

ts_data <- ts(pull(demand,AvrDemand),start=1,frequency = 1)
data_train <- pull(test,AvrDemand)

training_data <- window(ts_data, start = 1, end = length(test))
test_data <- window(ts_data, start = length(test)+1)

arima_optimal = auto.arima(training_data,trace = T)

sarima_forecast = sarima.for(training_data, n.ahead=length(test_data),
                             p=3,d=1,q=3,P=0,D=0,Q=0,S=31)
MAPE(sarima_forecast$pred, test_data) * 100

# forecasting last 2 months
one_step_ahead_sarima = matrix(ncol = 2, nrow = 60)
for (i in 1:60){
  
  training_observed = window(ts_data, start = 1, end = length(data_train)+i, frequency = 1)
  
  forecasted.sarima = sarima.for(training_observed,n.ahead=1,p=3,d=1,q=3,P=0,D=0,Q=0,S=31)
  
  demandforecast = forecasted.sarima$pred
  observed = test_data[[i]]
  
  one_step_ahead_sarima[i,1]= observed
  one_step_ahead_sarima[i,2]= demandforecast
}
MAPE(one_step_ahead_sarima[,1], one_step_ahead_sarima[,2]) * 100

plot(ts_data, col="blue", xlab="Time", ylab="AvgIEDemand", main="SARIMA Forecast", type='l')
lines(ts(one_step_ahead_sarima[,2], length(data_train)+1, frequency = 1), col="red", lwd=3)
###################################################
