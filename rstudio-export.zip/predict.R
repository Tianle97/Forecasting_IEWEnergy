library(aimsir17)
library(astsa)
library(dplyr)
library(forecast)
library(ggplot2)
library(MLmetrics)
library(tseries)

hr_demand <- eirgrid17 %>%
  group_by(month,day,hour) %>%
  summarise(Time=first(date),
            AvrHrDemand=mean(IEDemand),
            AvrWindGen=mean(IEGeneration))

test <- filter(hr_demand,month==1)

ts_data <- pull(test,AvrHrDemand)

ts_1       <- ts(ts_data,start=1,frequency = 31)
plot.ts(ts_1)

# check acf and pacf
acf(ts_1, lag.max=30)

pacf(ts_1, lag.max=30)

# get the best model
au_1 <- auto.arima(ts_1,trace=T)
#from acf and pacf can got arima (1,1,1) is best model
#arima(ts_1,order=c(1,1,1))
#arima_ts <- arima(ts_1,order=c(1,1,1))

f_ts <- forecast(au_1,h=24)
plot(f_ts)
# generate forecasting plot
plot(forecast(arima_ts,h=24))

ggplot(filter(hr_demand,month==1,day %in% 9:10),aes(x=Time,y=AvrHrDemand))+geom_point()+geom_line()

ggplot(test,aes(x=Time,y=AvrWindGen))+geom_point()+geom_line()

components.ts = decompose(ts_1)
plot(components.ts)

ao = auto.arima(ts_1_log)
predict(ao,n.ahead = 10,se.fit=T)
f <- forecast(ao,h=24)
plot(f)


# predict next month total rainfall in station Mace Head
MH_weather <- observations %>%
  group_by(month,day,station) %>%
  summarise(Time=first(date),
            TotalRainfall=sum(rain),
            MaxTemp=max(temp),
            MeanWind=mean(wdsp)) %>%
  filter(station=="MACE HEAD")

weather <- filter(MH_weather,month==1)


rainMH_data <- pull(weather,TotalRainfall)
ts_MH       <- ts(rainMH_data,start=1,frequency = 30)
plot.ts(ts_MH)

# check acf and pacf
acf(ts_MH, lag.max=30)

pacf(ts_MH, lag.max=30)

# get the best model
auto.arima(ts_MH,trace=T)
#from acf and pacf can got arima (2,1,0) is best model
#arima(ts_1,order=c(2,1,0))
arima_MH <- arima(ts_MH,order=c(2,1,0))

f_MH <- forecast(arima_MH,h=30,level=c(99.5))
# generate forecasting plot
plot(forecast(arima_MH,h=30))


ggplot(filter(MH_weather,month %in% 1:2),aes(x=Time,y=TotalRainfall))+geom_point()+geom_line()
ggplot(weather,aes(x=Time,y=MaxTemp))+geom_point()+geom_line()



summ <- observations %>% group_by(station,month,day) %>%
  summarise(AvrWin=mean(wdsp,na.rm=T)) %>% ungroup()

test <- filter(summ,station=="MACE HEAD") %>% slice(1:100)

ts_data <- pull(test,AvrWin)

training_prop <- .8

ts1       <- ts(ts_data,start=1,end=length(ts_data))
train_set <- window(ts1,1,floor(length(ts1)*training_prop))
test_set  <- window(ts1,floor(length(ts1)*training_prop)+1,length(ts1))


ao = auto.arima(train_set)

predict(ao,n.ahead = 10,se.fit=T)

f <- forecast(ao,h=10)

plot(f)
